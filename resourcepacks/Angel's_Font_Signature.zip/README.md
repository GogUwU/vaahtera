# Angel's Font

Thank you for exploring Angel's Font! This resource pack is crafted to enhance your Minecraft UI experience with a more stylish and visually pleasing font design.

## Features
- **Per-Language Design**: Font designs are currently available for a few selected languages, with more to be added over time based on user vote requests.

## Technical Information
- **Minecraft Compatibility**: Compatible with Minecraft 1.14 and above.
- **Mod Compatibility**: Mods that modify the GUI or use custom fonts may override this pack’s font.

## Credits
- **Language Support**: Big thanks to a few friends who carefully tested various characters and letters to make sure they stayed true to the original Minecraft font style and matched the respective languages — helping me avoid mistakes in languages I'm less familiar with.

## Feedback & Support
Your feedback is invaluable! If you have suggestions, encounter issues, or simply want to share your thoughts, feel free to join my Discord server:  
https://discord.gg/t7JJPyxJ6k

Thank you for your interest and support. I hope you enjoy this resource pack and all it brings to your Minecraft adventures!

For support and donations visit my Ko-Fi:
https://ko-fi.com/liminalangel